/*
	IMPORTANT!
	A newer verison of this slideshow is available at:
	https://codepen.io/alexerlandsson/pen/ONqdZY
*/